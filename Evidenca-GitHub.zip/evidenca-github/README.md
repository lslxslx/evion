# Evidenca mësimore | UPT

Version statik për GitHub Pages. Formulari dhe PDF-ja përpunohen në shfletues, pa GAS, Google Sheets, login apo databazë. Të dhënat e formularit nuk dërgohen në server nga aplikacioni. Ruajeni draftin para se të mbyllni faqen.

## Publikimi në GitHub Pages

1. Krijoni një repository publik me emrin `evidenca`.
2. Zbërtheni ZIP-in. Hapni dosjen `evidenca-github`.
3. Te repository klikoni **Add file → Upload files**. Ngarkoni PËRMBAJTJEN e dosjes: `index.html`, `style.css`, `core.js`, `app.js`, `pdf.js`, `fonts`, `vendor` dhe README. Ruani strukturën e dy nëndosjeve. Mos ngarkoni vetëm ZIP-in ose dosjen prind.
4. Klikoni **Commit changes**.
5. Hapni **Settings → Pages**. Source: **Deploy from a branch**; Branch: **main**; Folder: **/(root)**. Klikoni **Save**.
6. Prisni publikimin; adresa shfaqet te Settings → Pages dhe ka formën `https://EMRI.github.io/evidenca/`.
7. Hapni faqen, plotësoni të dhënat, klikoni **Verifiko**, pastaj **Gjenero PDF**. Nëse shkarkimi automatik nuk nis, klikoni **Shkarko PDF**.

Skedari bosh `.nojekyll` përfshihet në paketë; nëse nuk shfaqet gjatë ngarkimit, mund ta krijoni në GitHub me **Add file → Create new file**, emri `.nojekyll`.

Për provë lokale mund të hapni `index.html` në kompjuter. Për një provë që i ngjan hostimit, nga kjo dosje përdorni `python3 -m http.server 8000` dhe hapni `http://localhost:8000`.

## Skedarët

- `index.html`: faqja dhe formulari.
- `style.css`: pamja aktuale, fonti dhe përshtatja mobile.
- `core.js`: formulat dhe verifikimet e Core.gs.
- `app.js`: regjistrimet, kalendari, draftet dhe butonat.
- `pdf.js`: paraqitja A4 dhe gjenerimi i PDF-së.
- `vendor/`: pdfmake 0.2.20, licenca MIT dhe fontet e koduara për PDF.
- `fonts/`: Comfortaa Regular/Bold dhe licenca SIL Open Font License.

Nuk nevojitet npm apo build për publikim. Fontet dhe gjeneruesi i PDF-së janë përfshirë lokalisht.

## Përputhja me GAS

- Maksimumi 100 regjistrime, sipas Core.gs të dërguar; kufiri është i njëjtë në formular, import dhe verifikim.
- Leksion: kredite × (12 Bachelor / 10 Master) × grupe.
- Seminar: kredite × (14 Bachelor / 12 Master) × grupe.
- Laborator: kredite × 20 × grupe.
- Detyrë/projekt: kredite × 5; Praktikë: kredite × 20. Grupet e këtyre dy kategorive paraqiten, por nuk shumëzojnë orët, sipas kodit të dërguar.
- Praktika shfaqet në formular vetëm kur ka kredite. Orët e fshehura ruhen dhe kontrollohen.
- Java automatike ka intervale 7-ditore; lejohet korrigjim manual.
- Data në PDF: dd.MM.yyyy. Kalendari native në formular ndjek gjuhën e pajisjes.
- PDF me Comfortaa të përfshirë, header gri, “Orë faktike” në qendër, shumat ditore bold, shënim me *.
- Nënshkrimet ndjekin Code.gs të fundit: PEDAGOG/E dhe DREJTUES DEPARTAMENTI, pa vijë firme.
- Draftet ekzistuese JSON version 1 mbështeten deri në 100 regjistrime. Draftet me më shumë regjistrime refuzohen; skedari origjinal nuk ndryshohet.

PDF-ja është rindërtuar me pdfmake; ndarja në faqe mund të ndryshojë nga konvertuesi GAS. Nuk është firmë dixhitale apo regjistër institucional i autentikuar.

## Kontrolli i kryer

Formulat për dy ciklet, kufijtë e grupeve, datat e pavlefshme, orët e fshehura të praktikës dhe PDF-të me 7 dhe 100 rreshta janë kontrolluar. PDF-të janë renderuar për të parë tabelën, përsëritjen e kokës në faqet vijuese dhe ë/ç. Në Chromium u provuan importi i draftit, verifikimi, shkarkimi real i PDF-së, bllokimi pas ndryshimit të të dhënave dhe mungesa e daljes jashtë ekranit në gjerësi 390/768/1280px. Prova në pajisjet reale iPhone/iPad mbetet e nevojshme.

## Burimet

- https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site
- https://pdfmake.github.io/docs/0.1/
- https://github.com/google/fonts/tree/main/ofl/comfortaa
